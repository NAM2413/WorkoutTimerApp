package com.example.workouttimerapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Chronometer;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView output;
    private EditText input;
    private Chronometer chronometer;
    private android.content.SharedPreferences SharedPreferences;
    private SharedPreferences.Editor Editor;

    private ImageButton ButtonStart, ButtonPause, ButtonStop;

    private long PausingTime;
    private boolean Run;
    private long time,minutes,seconds, GettingTime;

    String WorkingOutType,WorkingOut,SpendingTime;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        output = findViewById(R.id.TextView1);
        ButtonStart = findViewById(R.id.Starting);
        ButtonPause = findViewById(R.id.Pausing);
        ButtonStop = findViewById(R.id.Stoping);
        input = findViewById(R.id.EnteringType);

        chronometer = findViewById(R.id.chronometer);

        //loading data
        SharedPreferences = getSharedPreferences("data", MODE_PRIVATE);
        Editor = SharedPreferences.edit();
        PausingTime = 0;

        WorkingOutType = SharedPreferences.getString("WorkingOutType", "");
        time = SharedPreferences.getLong("time", 0);
        minutes = (time % (1000 * 60 * 60)) / (1000 * 60);
        seconds = (time % (1000 * 60)) / 1000;
        SpendingTime = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);

        output.setText("You spent " + SpendingTime + " on " + WorkingOutType + " last time.");

        if (savedInstanceState != null)
        {
            PausingTime = savedInstanceState.getLong("PausingTime", 0);
            Run = savedInstanceState.getBoolean("Run", true);
            GettingTime = savedInstanceState.getLong("GettingTime", 0);
            if (!Run)
            {
                chronometer.setBase(SystemClock.elapsedRealtime() - PausingTime);
                chronometer.stop();
                Run = false;
            }
            else if (Run)
            {
                chronometer.setBase(SystemClock.elapsedRealtime() - (SystemClock.elapsedRealtime() - GettingTime));
                chronometer.start();
                Run = true;
            }
        }
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putLong("PausingTime", PausingTime);
        outState.putBoolean("Run", Run);
        outState.putLong("GettingTime", chronometer.getBase());
    }

    // Started
    public void StartingChronometer(View view)
    {
        if (input.length() == 0)
        {
            Toast.makeText(MainActivity.this, "Please enter the workout you need!", Toast.LENGTH_SHORT).show();
        }
        else {
            if (!Run)
            {
                Run = true;
                chronometer.setBase(SystemClock.elapsedRealtime() - PausingTime);
                chronometer.start();
            }
        }
    }

    // Paused
    public void PausingChronometer(View view)
    {
        if (Run)
        {
            chronometer.stop();
            PausingTime = SystemClock.elapsedRealtime() - chronometer.getBase();
            Run = false;
        }
    }

    // Stoped
    private void updatedisplay(CharSequence time)
    {
        if (input.getText().toString().equals(""))
            output.setText("You have spent " + time + " on your WorkingTime at last time.");
        else output.setText("You have spent " + time + " on " + WorkingOut + " at last time.");
    }

    public void StopingChronometer(View view)
    {
        if (!Run)
        {
            chronometer.stop();
            long totalTime = PausingTime;
            Editor.putLong("GettingTime", totalTime);
            Editor.putString("WorkingOutType", input.getText().toString());
            Editor.apply();
            WorkingOut = input.getText().toString();
            updatedisplay(chronometer.getText());
            PausingTime = 0;
            chronometer.setBase(SystemClock.elapsedRealtime());

        } else {
            Toast.makeText(MainActivity.this, "Click pause button to continue!", Toast.LENGTH_SHORT).show();
        }
    }
}